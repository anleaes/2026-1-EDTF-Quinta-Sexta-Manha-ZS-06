import { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { Leaf, Menu, X, LogOut, User as UserIcon, History, MapPin } from 'lucide-react';

export default function Navbar() {
  const { user, signOut } = useAuth();
  const [isOpen, setIsOpen] = useState(false);
  const location = useLocation();
  const isLandingPage = location.pathname === '/';

  const handleSignOut = async () => {
    await signOut();
    setIsOpen(false);
  };

  return (
    <nav className={`fixed w-full z-50 transition-all duration-300 ${isLandingPage ? 'bg-transparent' : 'bg-white shadow-md'}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <Link to="/" className="flex items-center gap-2 group">
            <div className="w-10 h-10 bg-gradient-to-br from-primary-400 to-primary-600 rounded-xl flex items-center justify-center shadow-lg group-hover:shadow-primary-500/30 transition-shadow">
              <Leaf className={`w-6 h-6 ${isLandingPage ? 'text-white' : 'text-white'}`} />
            </div>
            <span className={`font-bold text-xl ${isLandingPage ? 'text-white' : 'text-gray-900'}`}>
              EcoColeta IA
            </span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-6">
            {user ? (
              <>
                <Link
                  to="/dashboard"
                  className={`font-medium transition-colors ${isLandingPage ? 'text-white/90 hover:text-white' : 'text-gray-600 hover:text-primary-600'}`}
                >
                  Dashboard
                </Link>
                <Link
                  to="/identify"
                  className={`font-medium transition-colors ${isLandingPage ? 'text-white/90 hover:text-white' : 'text-gray-600 hover:text-primary-600'}`}
                >
                  Identificar
                </Link>
                <Link
                  to="/collection-points"
                  className={`font-medium transition-colors ${isLandingPage ? 'text-white/90 hover:text-white' : 'text-gray-600 hover:text-primary-600'}`}
                >
                  Pontos de Coleta
                </Link>
                <div className="flex items-center gap-3 ml-4">
                  <Link
                    to="/history"
                    className={`p-2 rounded-lg transition-colors ${isLandingPage ? 'hover:bg-white/20 text-white' : 'hover:bg-gray-100 text-gray-600'}`}
                    title="Historico"
                  >
                    <History className="w-5 h-5" />
                  </Link>
                  <Link
                    to="/profile"
                    className={`w-10 h-10 rounded-full flex items-center justify-center ${isLandingPage ? 'bg-white/20' : 'bg-gray-100'}`}
                    title="Perfil"
                  >
                    <UserIcon className={`w-5 h-5 ${isLandingPage ? 'text-white' : 'text-gray-600'}`} />
                  </Link>
                  <button
                    onClick={handleSignOut}
                    className="flex items-center gap-2 px-4 py-2 rounded-xl bg-gray-100 hover:bg-gray-200 text-gray-700 font-medium transition-colors"
                  >
                    <LogOut className="w-4 h-4" />
                    Sair
                  </button>
                </div>
              </>
            ) : (
              <>
                <Link
                  to="/login"
                  className={`font-medium transition-colors ${isLandingPage ? 'text-white/90 hover:text-white' : 'text-gray-600 hover:text-primary-600'}`}
                >
                  Entrar
                </Link>
                <Link
                  to="/signup"
                  className="btn-primary"
                >
                  Cadastrar
                </Link>
              </>
            )}
          </div>

          {/* Mobile menu button */}
          <button
            onClick={() => setIsOpen(!isOpen)}
            className={`md:hidden p-2 rounded-lg ${isLandingPage ? 'text-white' : 'text-gray-700'}`}
          >
            {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Navigation */}
      {isOpen && (
        <div className="md:hidden bg-white border-t shadow-lg animate-slide-up">
          <div className="px-4 py-4 space-y-3">
            {user ? (
              <>
                <Link to="/dashboard" onClick={() => setIsOpen(false)} className="block py-2 px-4 rounded-lg text-gray-700 font-medium hover:bg-gray-50">
                  Dashboard
                </Link>
                <Link to="/identify" onClick={() => setIsOpen(false)} className="block py-2 px-4 rounded-lg text-gray-700 font-medium hover:bg-gray-50">
                  Identificar Residuo
                </Link>
                <Link to="/collection-points" onClick={() => setIsOpen(false)} className="block py-2 px-4 rounded-lg text-gray-700 font-medium hover:bg-gray-50 flex items-center gap-2">
                  <MapPin className="w-4 h-4" />
                  Pontos de Coleta
                </Link>
                <Link to="/history" onClick={() => setIsOpen(false)} className="block py-2 px-4 rounded-lg text-gray-700 font-medium hover:bg-gray-50 flex items-center gap-2">
                  <History className="w-4 h-4" />
                  Historico
                </Link>
                <Link to="/profile" onClick={() => setIsOpen(false)} className="block py-2 px-4 rounded-lg text-gray-700 font-medium hover:bg-gray-50 flex items-center gap-2">
                  <UserIcon className="w-4 h-4" />
                  Perfil
                </Link>
                <hr className="my-2" />
                <button onClick={handleSignOut} className="w-full text-left py-2 px-4 rounded-lg text-red-600 font-medium hover:bg-red-50 flex items-center gap-2">
                  <LogOut className="w-4 h-4" />
                  Sair
                </button>
              </>
            ) : (
              <>
                <Link to="/login" onClick={() => setIsOpen(false)} className="block py-2 px-4 rounded-lg text-gray-700 font-medium hover:bg-gray-50">
                  Entrar
                </Link>
                <Link to="/signup" onClick={() => setIsOpen(false)} className="block py-2 px-4 rounded-lg bg-primary-500 text-white font-medium text-center">
                  Cadastrar
                </Link>
              </>
            )}
          </div>
        </div>
      )}
    </nav>
  );
}
