import { useEffect, useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { ArrowLeft, Recycle, Clock, AlertTriangle, Leaf, CheckCircle, MapPin, Share2, Bookmark, Trash2, TreePine, Droplets, Gauge } from 'lucide-react';
import Navbar from '../components/Navbar';

interface WasteInfo {
  id: string;
  name: string;
  category: string;
  description: string;
  correct_disposal: string;
  recyclable: boolean;
  decomposition_time: string;
  environmental_impact: string;
  cares_needed: string;
  icon: string;
  color: string;
}

interface IdentificationResult {
  imageUrl: string;
  wasteType: string;
  disposalInstructions: string;
  createdAt: string;
  wasteInfo?: WasteInfo;
}

export default function ResultPage() {
  const navigate = useNavigate();
  const location = useLocation();
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [result, setResult] = useState<IdentificationResult | null>(null);

  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const identificationId = params.get('id');

    if (identificationId && user) {
      fetchIdentification(identificationId);
    } else if (location.state) {
      setResult(location.state);
      setLoading(false);
    } else {
      navigate('/identify');
    }
  }, [location, user, navigate]);

  async function fetchIdentification(id: string) {
    try {
      const { data, error } = await supabase
        .from('waste_identifications')
        .select('*')
        .eq('id', id)
        .eq('user_id', user?.id)
        .single();

      if (error) throw error;

      if (data) {
        const { data: wasteInfo } = await supabase
          .from('waste_types')
          .select('*')
          .ilike('name', `%${data.waste_type.split(' - ')[0]}%`)
          .limit(1)
          .single();

        setResult({
          imageUrl: data.image_url,
          wasteType: data.waste_type,
          disposalInstructions: data.disposal_instructions,
          createdAt: data.created_at,
          wasteInfo: wasteInfo || undefined,
        });
      }
    } catch (err) {
      console.error('Error fetching identification:', err);
    } finally {
      setLoading(false);
    }
  }

  const getImpactColor = (impact: string) => {
    switch (impact) {
      case 'Baixo': return 'text-green-600 bg-green-100';
      case 'Medio': return 'text-yellow-600 bg-yellow-100';
      case 'Alto': return 'text-orange-600 bg-orange-100';
      case 'Muito Alto': return 'text-red-600 bg-red-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getCategoryColor = (color: string) => {
    const colors: Record<string, string> = {
      blue: 'bg-blue-100 text-blue-700 border-blue-200',
      green: 'bg-green-100 text-green-700 border-green-200',
      yellow: 'bg-yellow-100 text-yellow-700 border-yellow-200',
      brown: 'bg-amber-100 text-amber-700 border-amber-200',
      red: 'bg-red-100 text-red-700 border-red-200',
      gray: 'bg-gray-100 text-gray-700 border-gray-200',
      black: 'bg-gray-800 text-white border-gray-700',
    };
    return colors[color] || colors.blue;
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        <div className="pt-24 flex items-center justify-center">
          <div className="w-8 h-8 border-4 border-primary-500 border-t-transparent rounded-full animate-spin" />
        </div>
      </div>
    );
  }

  if (!result) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        <div className="pt-24 max-w-md mx-auto px-4 text-center">
          <h2 className="text-xl font-bold text-gray-900 mb-4">Nenhuma identificacao encontrada</h2>
          <button onClick={() => navigate('/identify')} className="btn-primary">
            Nova Identificacao
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 pt-24 pb-12">
        <button
          onClick={() => navigate(-1)}
          className="inline-flex items-center gap-2 text-gray-600 hover:text-primary-600 transition-colors mb-6"
        >
          <ArrowLeft className="w-5 h-5" />
          Voltar
        </button>

        <div className="grid lg:grid-cols-2 gap-6">
          {/* Image Section */}
          <div className="card overflow-hidden">
            <img
              src={result.imageUrl}
              alt="Residuo identificado"
              className="w-full h-64 lg:h-80 object-cover rounded-xl mb-4"
            />
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-500">
                Identificado em {new Date(result.createdAt || Date.now()).toLocaleDateString('pt-BR')}
              </span>
              <div className="flex gap-2">
                <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors" title="Salvar">
                  <Bookmark className="w-5 h-5 text-gray-500" />
                </button>
                <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors" title="Compartilhar">
                  <Share2 className="w-5 h-5 text-gray-500" />
                </button>
              </div>
            </div>
          </div>

          {/* Results Section */}
          <div className="space-y-4">
            {/* Main Result Card */}
            <div className="card">
              <div className="flex items-center gap-2 text-primary-600 mb-3">
                <CheckCircle className="w-5 h-5" />
                <span className="font-medium text-sm">Identificado com sucesso</span>
              </div>

              <div className={`p-5 rounded-xl mb-4 border ${getCategoryColor(result.wasteInfo?.color || 'blue')}`}>
                <div className="flex items-center gap-4">
                  <div className="text-4xl">{result.wasteInfo?.icon || '♻️'}</div>
                  <div>
                    <h1 className="text-xl font-bold">{result.wasteType}</h1>
                    <p className="text-sm opacity-80">{result.wasteInfo?.category || 'Categoria'}</p>
                  </div>
                </div>
              </div>

              {/* Quick Stats Grid */}
              <div className="grid grid-cols-2 gap-3 mb-4">
                <div className="bg-gray-50 rounded-xl p-3 text-center">
                  <div className="flex items-center justify-center gap-1 mb-1">
                    <Recycle className={`w-4 h-4 ${result.wasteInfo?.recyclable ? 'text-green-600' : 'text-red-500'}`} />
                    <span className="text-xs text-gray-500">Reciclavel</span>
                  </div>
                  <span className={`font-bold ${result.wasteInfo?.recyclable ? 'text-green-600' : 'text-red-500'}`}>
                    {result.wasteInfo?.recyclable ? 'Sim' : 'Nao'}
                  </span>
                </div>

                <div className="bg-gray-50 rounded-xl p-3 text-center">
                  <div className="flex items-center justify-center gap-1 mb-1">
                    <Clock className="w-4 h-4 text-gray-500" />
                    <span className="text-xs text-gray-500">Decomposicao</span>
                  </div>
                  <span className="font-bold text-gray-900 text-sm">
                    {result.wasteInfo?.decomposition_time || 'N/A'}
                  </span>
                </div>

                <div className="bg-gray-50 rounded-xl p-3 text-center">
                  <div className="flex items-center justify-center gap-1 mb-1">
                    <Gauge className="w-4 h-4 text-gray-500" />
                    <span className="text-xs text-gray-500">Impacto</span>
                  </div>
                  <span className={`font-bold text-sm px-2 py-1 rounded-full ${getImpactColor(result.wasteInfo?.environmental_impact || 'Medio')}`}>
                    {result.wasteInfo?.environmental_impact}
                  </span>
                </div>

                <div className="bg-gray-50 rounded-xl p-3 text-center">
                  <div className="flex items-center justify-center gap-1 mb-1">
                    <Leaf className="w-4 h-4 text-gray-500" />
                    <span className="text-xs text-gray-500">Categoria</span>
                  </div>
                  <span className="font-bold text-gray-900 text-sm">
                    {result.wasteInfo?.category || 'N/A'}
                  </span>
                </div>
              </div>
            </div>

            {/* Description */}
            {result.wasteInfo?.description && (
              <div className="card">
                <h3 className="font-bold text-gray-900 mb-2 flex items-center gap-2">
                  <Droplets className="w-5 h-5 text-secondary-500" />
                  Descricao
                </h3>
                <p className="text-gray-600 text-sm leading-relaxed">
                  {result.wasteInfo.description}
                </p>
              </div>
            )}
          </div>
        </div>

        {/* Full Width Sections */}
        <div className="mt-6 space-y-6">
          {/* Correct Disposal */}
          <div className="card">
            <h3 className="font-bold text-gray-900 mb-4 flex items-center gap-2 text-lg">
              <Trash2 className="w-6 h-6 text-primary-500" />
              Forma Correta de Descarte
            </h3>
            <div className="bg-primary-50 border border-primary-200 rounded-xl p-5">
              <p className="text-gray-700 leading-relaxed">
                {result.wasteInfo?.correct_disposal || result.disposalInstructions}
              </p>
            </div>
          </div>

          {/* Cares Needed */}
          {result.wasteInfo?.cares_needed && (
            <div className="card">
              <h3 className="font-bold text-gray-900 mb-4 flex items-center gap-2 text-lg">
                <AlertTriangle className="w-6 h-6 text-amber-500" />
                Cuidados Necessarios
              </h3>
              <div className="bg-amber-50 border border-amber-200 rounded-xl p-5">
                <p className="text-gray-700 leading-relaxed">{result.wasteInfo.cares_needed}</p>
              </div>
            </div>
          )}

          {/* Environmental Impact Details */}
          <div className="card">
            <h3 className="font-bold text-gray-900 mb-4 flex items-center gap-2 text-lg">
              <TreePine className="w-6 h-6 text-green-500" />
              Impacto Ambiental
            </h3>
            <div className="grid sm:grid-cols-3 gap-4">
              <div className="bg-green-50 rounded-xl p-4 text-center">
                <TreePine className="w-8 h-8 text-green-500 mx-auto mb-2" />
                <p className="font-bold text-green-700">
                  {result.wasteInfo?.recyclable ? 'Baixo' : 'Alto'}
                </p>
                <p className="text-xs text-gray-500 mt-1">Impacto ambiental</p>
              </div>
              <div className="bg-blue-50 rounded-xl p-4 text-center">
                <Droplets className="w-8 h-8 text-blue-500 mx-auto mb-2" />
                <p className="font-bold text-blue-700">
                  {result.wasteInfo?.recyclable ? 'Minimo' : 'Significativo'}
                </p>
                <p className="text-xs text-gray-500 mt-1">Contaminacao agua</p>
              </div>
              <div className="bg-primary-50 rounded-xl p-4 text-center">
                <Gauge className="w-8 h-8 text-primary-500 mx-auto mb-2" />
                <p className="font-bold text-primary-700">
                  {result.wasteInfo?.decomposition_time || 'Indeterminado'}
                </p>
                <p className="text-xs text-gray-500 mt-1">Tempo decomposicao</p>
              </div>
            </div>
          </div>

          {/* Collection Points Button */}
          <button
            onClick={() => navigate(`/collection-points?category=${encodeURIComponent(result.wasteInfo?.category || 'Plastico')}`)}
            className="w-full btn-secondary flex items-center justify-center gap-2 text-lg py-4"
          >
            <MapPin className="w-5 h-5" />
            Ver Pontos de Coleta Proximos
          </button>

          {/* Actions */}
          <div className="flex gap-4">
            <button
              onClick={() => navigate('/identify')}
              className="flex-1 btn-outline"
            >
              Nova Identificacao
            </button>
            <button
              onClick={() => navigate('/dashboard')}
              className="flex-1 btn-primary"
            >
              Ver no Dashboard
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
