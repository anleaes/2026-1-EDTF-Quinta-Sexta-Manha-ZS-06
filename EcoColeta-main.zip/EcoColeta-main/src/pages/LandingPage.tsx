import { Link } from 'react-router-dom';
import { Camera, Sparkles, Recycle, Leaf, ArrowRight, Users, Trash2, TreePine, Globe } from 'lucide-react';
import Navbar from '../components/Navbar';

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-primary-600 via-primary-500 to-secondary-500">
      <Navbar />

      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center px-4 pt-16 overflow-hidden">
        {/* Background Elements */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-20 left-10 w-72 h-72 bg-white/10 rounded-full blur-3xl" />
          <div className="absolute bottom-20 right-10 w-96 h-96 bg-secondary-400/20 rounded-full blur-3xl" />
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-white/5 rounded-full blur-3xl" />
        </div>

        <div className="relative max-w-4xl mx-auto text-center mt-8">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/10 backdrop-blur-sm rounded-full text-white/90 text-sm font-medium mb-8 animate-fade-in">
            <Leaf className="w-4 h-4" />
            <span>Inteligencia Artificial para um mundo mais verde</span>
          </div>

          <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold text-white mb-6 leading-tight animate-slide-up">
            Descarte corretamente.
            <br />
            <span className="text-white/90">Preserve o futuro.</span>
          </h1>

          <p className="text-lg md:text-xl text-white/80 mb-10 max-w-2xl mx-auto leading-relaxed animate-slide-up">
            Tire uma foto do seu residuo e nossa IA ira identificar instantaneamente,
            te orientando sobre a forma correta de descarte e reciclagem.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center animate-slide-up">
            <Link
              to="/signup"
              className="inline-flex items-center justify-center gap-2 bg-white text-primary-600 font-bold py-4 px-8 rounded-2xl text-lg hover:bg-gray-50 transition-all duration-300 hover:shadow-xl hover:shadow-white/20 active:scale-95"
            >
              Comecar Agora
              <ArrowRight className="w-5 h-5" />
            </Link>
            <a
              href="#how-it-works"
              className="inline-flex items-center justify-center gap-2 bg-white/10 backdrop-blur-sm text-white font-semibold py-4 px-8 rounded-2xl text-lg hover:bg-white/20 transition-all duration-300"
            >
              Como Funciona
            </a>
          </div>

          {/* Floating Cards Preview */}
          <div className="mt-16 perspective-1000">
            <div className="relative max-w-sm mx-auto">
              <div className="absolute -inset-4 bg-white/20 rounded-3xl blur-xl" />
              <div className="relative bg-white rounded-2xl p-4 shadow-2xl transform hover:scale-105 transition-transform duration-300">
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 bg-gradient-to-br from-primary-400 to-primary-600 rounded-xl flex items-center justify-center">
                    <Recycle className="w-8 h-8 text-white" />
                  </div>
                  <div className="flex-1 text-left">
                    <div className="text-sm text-gray-500 font-medium">Identificado</div>
                    <div className="text-lg font-bold text-gray-900">Garrafa PET</div>
                    <div className="text-sm text-primary-600 font-medium">Plastico - Reciclavel</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Scroll Indicator */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce-gentle">
          <div className="w-6 h-10 border-2 border-white/50 rounded-full flex justify-center">
            <div className="w-1 h-3 bg-white/50 rounded-full mt-2 animate-pulse" />
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section id="how-it-works" className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Como Funciona
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Em apenas 3 passos simples, voce contribui para um mundo mais sustentavel
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {/* Step 1 */}
            <div className="relative group">
              <div className="card hover:bg-primary-50 border-2 border-transparent hover:border-primary-200">
                <div className="absolute -top-4 -left-4 w-10 h-10 bg-primary-500 rounded-full flex items-center justify-center text-white font-bold text-lg shadow-lg">
                  1
                </div>
                <div className="w-16 h-16 bg-primary-100 rounded-2xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300">
                  <Camera className="w-8 h-8 text-primary-600" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">Tire uma Foto</h3>
                <p className="text-gray-600">
                  Use seu smartphone para fotografar qualquer residuo que deseja descartar corretamente.
                </p>
              </div>
            </div>

            {/* Step 2 */}
            <div className="relative group">
              <div className="card hover:bg-secondary-50 border-2 border-transparent hover:border-secondary-200">
                <div className="absolute -top-4 -left-4 w-10 h-10 bg-secondary-500 rounded-full flex items-center justify-center text-white font-bold text-lg shadow-lg">
                  2
                </div>
                <div className="w-16 h-16 bg-secondary-100 rounded-2xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300">
                  <Sparkles className="w-8 h-8 text-secondary-600" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">IA Identifica</h3>
                <p className="text-gray-600">
                  Nossa inteligencia artificial analisa a imagem e identifica o tipo de residuo instantaneamente.
                </p>
              </div>
            </div>

            {/* Step 3 */}
            <div className="relative group">
              <div className="card hover:bg-primary-50 border-2 border-transparent hover:border-primary-200">
                <div className="absolute -top-4 -left-4 w-10 h-10 bg-primary-500 rounded-full flex items-center justify-center text-white font-bold text-lg shadow-lg">
                  3
                </div>
                <div className="w-16 h-16 bg-primary-100 rounded-2xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300">
                  <Recycle className="w-8 h-8 text-primary-600" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">Receba Instrucoes</h3>
                <p className="text-gray-600">
                  Aprenda a forma correta de descarte e os pontos de coleta mais proximos de voce.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Impact Statistics Section */}
      <section className="py-24 bg-gradient-to-br from-gray-50 to-primary-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Nosso Impacto Ambiental
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Juntos estamos fazendo a diferenca. Veja os numeros que refletem nossa contribuicao para o planeta.
            </p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="card text-center hover:transform hover:-translate-y-1 transition-all duration-300">
              <div className="w-14 h-14 bg-primary-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <Users className="w-7 h-7 text-primary-600" />
              </div>
              <div className="text-4xl font-bold text-gray-900 mb-1">12.500+</div>
              <div className="text-gray-600">Usuarios Ativos</div>
            </div>

            <div className="card text-center hover:transform hover:-translate-y-1 transition-all duration-300">
              <div className="w-14 h-14 bg-secondary-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <Trash2 className="w-7 h-7 text-secondary-600" />
              </div>
              <div className="text-4xl font-bold text-gray-900 mb-1">45.000+</div>
              <div className="text-gray-600">Residuos Identificados</div>
            </div>

            <div className="card text-center hover:transform hover:-translate-y-1 transition-all duration-300">
              <div className="w-14 h-14 bg-primary-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <TreePine className="w-7 h-7 text-primary-600" />
              </div>
              <div className="text-4xl font-bold text-gray-900 mb-1">2.800</div>
              <div className="text-gray-600">Arvores Economizadas</div>
            </div>

            <div className="card text-center hover:transform hover:-translate-y-1 transition-all duration-300">
              <div className="w-14 h-14 bg-secondary-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <Globe className="w-7 h-7 text-secondary-600" />
              </div>
              <div className="text-4xl font-bold text-gray-900 mb-1">150 ton</div>
              <div className="text-gray-600">CO2 Evitado</div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 bg-gradient-to-r from-primary-600 to-secondary-600">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
            Pronto para fazer a diferenca?
          </h2>
          <p className="text-lg text-white/90 mb-8 max-w-2xl mx-auto">
            Junte-se a milhares de pessoas que ja estao contribuindo para um futuro mais sustentavel.
            Comece agora mesmo - e gratuito!
          </p>
          <Link
            to="/signup"
            className="inline-flex items-center justify-center gap-2 bg-white text-primary-600 font-bold py-4 px-10 rounded-2xl text-lg hover:bg-gray-50 transition-all duration-300 hover:shadow-xl active:scale-95"
          >
            Criar Conta Gratis
            <ArrowRight className="w-5 h-5" />
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8 mb-12">
            <div className="md:col-span-2">
              <div className="flex items-center gap-2 mb-4">
                <div className="w-10 h-10 bg-gradient-to-br from-primary-400 to-primary-600 rounded-xl flex items-center justify-center">
                  <Leaf className="w-6 h-6 text-white" />
                </div>
                <span className="font-bold text-xl">EcoColeta IA</span>
              </div>
              <p className="text-gray-400 mb-6 max-w-md">
                Utilizando inteligencia artificial para transformar a forma como lidamos com residuos,
                promovendo sustentabilidade e consciencia ambiental.
              </p>
            </div>

            <div>
              <h4 className="font-bold text-lg mb-4">Links Rapidos</h4>
              <ul className="space-y-2 text-gray-400">
                <li><Link to="/" className="hover:text-white transition-colors">Inicio</Link></li>
                <li><a href="#how-it-works" className="hover:text-white transition-colors">Como Funciona</a></li>
                <li><Link to="/signup" className="hover:text-white transition-colors">Cadastrar</Link></li>
                <li><Link to="/login" className="hover:text-white transition-colors">Entrar</Link></li>
              </ul>
            </div>

            <div>
              <h4 className="font-bold text-lg mb-4">Contato</h4>
              <ul className="space-y-2 text-gray-400">
                <li>contato@ecocoleta.com.br</li>
                <li>Suporte: (11) 9999-9999</li>
                <li>Sao Paulo, SP - Brasil</li>
              </ul>
            </div>
          </div>

          <div className="border-t border-gray-800 pt-8 text-center text-gray-500">
            <p>&copy; 2024 EcoColeta IA. Todos os direitos reservados.</p>
            <p className="mt-2 text-sm">Feito com amor pelo meio ambiente</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
