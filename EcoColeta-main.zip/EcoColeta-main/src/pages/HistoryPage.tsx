import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import { ArrowLeft, Clock, Calendar, Search, ChevronRight, Trash2, Recycle } from 'lucide-react';
import Navbar from '../components/Navbar';

interface Identification {
  id: string;
  image_url: string;
  waste_type: string;
  disposal_instructions: string;
  created_at: string;
}

export default function HistoryPage() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [identifications, setIdentifications] = useState<Identification[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedDate, setSelectedDate] = useState('');
  const [selectedType, setSelectedType] = useState('');
  const [stats, setStats] = useState({ total: 0, recyclable: 0, nonRecyclable: 0 });

  useEffect(() => {
    if (user) {
      fetchIdentifications();
    }
  }, [user, selectedDate, selectedType]);

  async function fetchIdentifications() {
    try {
      let query = supabase
        .from('waste_identifications')
        .select('*')
        .eq('user_id', user?.id)
        .order('created_at', { ascending: false });

      if (selectedDate) {
        const start = new Date(selectedDate);
        start.setHours(0, 0, 0, 0);
        const end = new Date(selectedDate);
        end.setHours(23, 59, 59, 999);
        query = query.gte('created_at', start.toISOString()).lte('created_at', end.toISOString());
      }

      if (selectedType) {
        query = query.ilike('waste_type', `%${selectedType}%`);
      }

      const { data, error } = await query;

      if (error) throw error;

      if (data) {
        setIdentifications(data);
        const recyclableKeywords = ['reciclavel', 'recicl', 'plastico', 'papel', 'metal', 'vidro'];
        const recyclable = data.filter(i =>
          recyclableKeywords.some(k => i.waste_type?.toLowerCase().includes(k))
        ).length;
        setStats({
          total: data.length,
          recyclable,
          nonRecyclable: data.length - recyclable,
        });
      }
    } catch (err) {
      console.error('Error fetching identifications:', err);
    } finally {
      setLoading(false);
    }
  }

  async function deleteIdentification(id: string) {
    try {
      const { error } = await supabase
        .from('waste_identifications')
        .delete()
        .eq('id', id)
        .eq('user_id', user?.id);

      if (error) throw error;

      setIdentifications(prev => prev.filter(i => i.id !== id));
      setStats(prev => ({ ...prev, total: prev.total - 1 }));
    } catch (err) {
      console.error('Error deleting identification:', err);
    }
  }

  const filteredIdentifications = identifications.filter(i =>
    i.waste_type?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    i.disposal_instructions?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const today = new Date();
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);

    if (date.toDateString() === today.toDateString()) {
      return 'Hoje';
    } else if (date.toDateString() === yesterday.toDateString()) {
      return 'Ontem';
    } else {
      return date.toLocaleDateString('pt-BR', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
      });
    }
  };

  const formatTime = (dateString: string) => {
    return new Date(dateString).toLocaleTimeString('pt-BR', {
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const groupByDate = (items: Identification[]) => {
    const groups: Record<string, Identification[]> = {};
    items.forEach(item => {
      const date = new Date(item.created_at).toLocaleDateString('pt-BR');
      if (!groups[date]) {
        groups[date] = [];
      }
      groups[date].push(item);
    });
    return groups;
  };

  const groupedIdentifications = groupByDate(filteredIdentifications);
  const uniqueTypes = [...new Set(identifications.map(i => i.waste_type).filter(Boolean))];

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        <div className="pt-24 flex items-center justify-center">
          <div className="w-8 h-8 border-4 border-primary-500 border-t-transparent rounded-full animate-spin" />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 pt-24 pb-12">
        <button
          onClick={() => navigate(-1)}
          className="inline-flex items-center gap-2 text-gray-600 hover:text-primary-600 transition-colors mb-6"
        >
          <ArrowLeft className="w-5 h-5" />
          Voltar
        </button>

        <div className="mb-6">
          <h1 className="text-2xl md:text-3xl font-bold text-gray-900">Historico de Consultas</h1>
          <p className="text-gray-600">Todos os residuos identificados por voce</p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-3 gap-3 mb-6">
          <div className="card text-center py-4">
            <div className="text-2xl font-bold text-gray-900">{stats.total}</div>
            <div className="text-xs text-gray-500">Total</div>
          </div>
          <div className="card text-center py-4">
            <div className="text-2xl font-bold text-green-600">{stats.recyclable}</div>
            <div className="text-xs text-gray-500">Reciclaveis</div>
          </div>
          <div className="card text-center py-4">
            <div className="text-2xl font-bold text-amber-600">{stats.nonRecyclable}</div>
            <div className="text-xs text-gray-500">Nao reciclaveis</div>
          </div>
        </div>

        {/* Search and Filters */}
        <div className="card mb-6">
          <div className="flex flex-col md:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="text"
                placeholder="Buscar por tipo ou descricao..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="input-field pl-12"
              />
            </div>

            <div className="flex gap-2">
              <select
                value={selectedType}
                onChange={(e) => setSelectedType(e.target.value)}
                className="input-field w-auto"
              >
                <option value="">Todos os tipos</option>
                {uniqueTypes.map(type => (
                  <option key={type} value={type}>{type}</option>
                ))}
              </select>

              <input
                type="date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                className="input-field w-auto"
              />
            </div>
          </div>

          {(searchTerm || selectedDate || selectedType) && (
            <button
              onClick={() => {
                setSearchTerm('');
                setSelectedDate('');
                setSelectedType('');
              }}
              className="mt-3 text-sm text-primary-600 hover:text-primary-700 font-medium"
            >
              Limpar filtros
            </button>
          )}
        </div>

        {/* History List */}
        {Object.keys(groupedIdentifications).length === 0 ? (
          <div className="card text-center py-12">
            <Clock className="w-12 h-12 text-gray-300 mx-auto mb-4" />
            <h3 className="font-medium text-gray-900 mb-2">Nenhuma identificacao encontrada</h3>
            <p className="text-gray-500 mb-4">Comece identificando seu primeiro residuo!</p>
            <button onClick={() => navigate('/identify')} className="btn-primary">
              Identificar Residuo
            </button>
          </div>
        ) : (
          <div className="space-y-6">
            {Object.entries(groupedIdentifications).map(([date, items]) => (
              <div key={date}>
                <div className="flex items-center gap-2 mb-3">
                  <Calendar className="w-4 h-4 text-gray-400" />
                  <span className="text-sm font-medium text-gray-500">
                    {formatDate(items[0].created_at)}
                  </span>
                  <span className="text-xs text-gray-400">({items.length} itens)</span>
                </div>

                <div className="space-y-3">
                  {items.map(item => (
                    <div
                      key={item.id}
                      className="card hover:shadow-lg transition-shadow"
                    >
                      <div className="flex items-center gap-4">
                        {item.image_url ? (
                          <img
                            src={item.image_url}
                            alt="Residuo"
                            className="w-16 h-16 rounded-xl object-cover"
                          />
                        ) : (
                          <div className="w-16 h-16 bg-primary-100 rounded-xl flex items-center justify-center">
                            <Recycle className="w-8 h-8 text-primary-500" />
                          </div>
                        )}

                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between mb-1">
                            <h3 className="font-semibold text-gray-900 truncate">{item.waste_type}</h3>
                            <div className="flex items-center gap-1 text-sm text-gray-400">
                              <Clock className="w-3 h-3" />
                              {formatTime(item.created_at)}
                            </div>
                          </div>
                          <p className="text-sm text-gray-500 truncate">{item.disposal_instructions}</p>
                        </div>

                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => navigate(`/result?id=${item.id}`)}
                            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
                            title="Ver detalhes"
                          >
                            <ChevronRight className="w-5 h-5 text-gray-400" />
                          </button>
                          <button
                            onClick={() => {
                              if (confirm('Deseja excluir esta identificacao?')) {
                                deleteIdentification(item.id);
                              }
                            }}
                            className="p-2 hover:bg-red-50 rounded-lg transition-colors"
                            title="Excluir"
                          >
                            <Trash2 className="w-5 h-5 text-red-400 hover:text-red-500" />
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
