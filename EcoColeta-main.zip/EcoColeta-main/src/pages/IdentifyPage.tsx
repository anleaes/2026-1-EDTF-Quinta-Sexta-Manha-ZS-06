import { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import { Camera, Upload, X, Recycle, MapPin, AlertTriangle, Leaf, CheckCircle, ArrowLeft, Sparkles, Clock, Gauge } from 'lucide-react';
import Navbar from '../components/Navbar';

interface AIResult {
  name: string;
  category: string;
  recyclable: boolean;
  decompositionTime: string;
  environmentalImpact: 'Baixo' | 'Medio' | 'Alto' | 'Muito Alto';
  correctDisposal: string;
  caresNeeded: string;
  confidence: number;
}

interface DisplayResult {
  type: string;
  icon: string;
  color: string;
  disposal: string;
  points: string[];
  aiResult: AIResult;
}

const CATEGORY_ICONS: Record<string, string> = {
  'Plastico': '♻️',
  'Papel': '📄',
  'Metal': '🥫',
  'Vidrio': '🍾',
  'Organico': '🍃',
  'Eletronico': '📱',
  'Bateria': '🔋',
  'Oleo': '🫗',
  'Farmaceutico': '💊',
  'Borracha': '🛞',
  'Outro': '❓',
};

const CATEGORY_COLORS: Record<string, string> = {
  'Plastico': 'blue',
  'Papel': 'blue',
  'Metal': 'yellow',
  'Vidrio': 'green',
  'Organico': 'brown',
  'Eletronico': 'gray',
  'Bateria': 'red',
  'Oleo': 'yellow',
  'Farmaceutico': 'red',
  'Borracha': 'gray',
  'Outro': 'gray',
};

const CATEGORY_POINTS: Record<string, string[]> = {
  'Plastico': ['Lixeiras azuis de reciclagem', 'Pontos de coleta seletiva', 'Supermercados com coleta'],
  'Papel': ['Lixeiras azuis de reciclagem', 'Escolas com coleta', 'Pontos de coleta'],
  'Metal': ['Lixeiras amarelas', 'Sucatas', 'Pontos de reciclagem'],
  'Vidrio': ['Lixeiras verdes', 'Pontos de coleta especializada'],
  'Organico': ['Composteira', 'Lixeira marrom', 'Hortas comunitarias'],
  'Eletronico': ['Pontos de coleta de e-lixo', 'Lojas de eletronicos', 'Prefeitura'],
  'Bateria': ['Pontos de coleta de pilhas', 'Supermercados', 'Lojas de eletronicos'],
  'Oleo': ['Pontos de coleta de oleo', 'Escolas', 'OCIPs'],
  'Farmaceutico': ['Farmacias', 'Postos de saude', 'Drogarias'],
  'Borracha': ['Borracharias', 'Pontos de coleta de pneus'],
  'Outro': ['Lixo comum', 'Consulte a prefeitura local'],
};

export default function IdentifyPage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [result, setResult] = useState<DisplayResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleImageCapture = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        setSelectedImage(event.target?.result as string);
        setResult(null);
        setError(null);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const file = e.dataTransfer.files[0];
    if (file && file.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onload = (event) => {
        setSelectedImage(event.target?.result as string);
        setResult(null);
        setError(null);
      };
      reader.readAsDataURL(file);
    }
  };

  const analyzeImage = async () => {
    if (!selectedImage || !user) return;

    setAnalyzing(true);
    setError(null);

    try {
      // Call the edge function with Gemini AI
      const { data, error: functionError } = await supabase.functions.invoke('identify-waste', {
        body: { image: selectedImage },
      });

      if (functionError) {
        console.error('Edge function error:', functionError);
        setError('Erro ao analisar imagem. Por favor, tente novamente.');
        setAnalyzing(false);
        return;
      }

      const aiResult: AIResult = data;

      // Map AI result to display format
      const category = aiResult.category || 'Outro';
      const displayResult: DisplayResult = {
        type: aiResult.name || 'Residuo Identificado',
        icon: CATEGORY_ICONS[category] || '♻️',
        color: CATEGORY_COLORS[category] || 'gray',
        disposal: aiResult.correctDisposal || 'Descarte conforme orientacoes locais.',
        points: CATEGORY_POINTS[category] || ['Consulte a prefeitura local'],
        aiResult,
      };

      setResult(displayResult);

      // Save to database
      const { error: insertError } = await supabase.from('waste_identifications').insert({
        user_id: user.id,
        image_url: selectedImage,
        waste_type: `${aiResult.name} - ${aiResult.category}`,
        disposal_instructions: aiResult.correctDisposal,
      });

      if (insertError) {
        console.error('Error saving identification:', insertError);
      }
    } catch (err) {
      console.error('Error analyzing image:', err);
      setError('Erro ao analisar imagem. Por favor, tente novamente.');
    }

    setAnalyzing(false);
  };

  const resetCapture = () => {
    setSelectedImage(null);
    setResult(null);
    setError(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const getColorClasses = (color: string) => {
    const colors: Record<string, { bg: string; text: string; border: string }> = {
      blue: { bg: 'bg-blue-100', text: 'text-blue-600', border: 'border-blue-200' },
      green: { bg: 'bg-green-100', text: 'text-green-600', border: 'border-green-200' },
      yellow: { bg: 'bg-yellow-100', text: 'text-yellow-600', border: 'border-yellow-200' },
      brown: { bg: 'bg-amber-100', text: 'text-amber-600', border: 'border-amber-200' },
      red: { bg: 'bg-red-100', text: 'text-red-600', border: 'border-red-200' },
      gray: { bg: 'bg-gray-100', text: 'text-gray-600', border: 'border-gray-200' },
    };
    return colors[color] || colors.blue;
  };

  const getImpactColor = (impact: string) => {
    switch (impact) {
      case 'Baixo': return 'bg-green-100 text-green-700';
      case 'Medio': return 'bg-yellow-100 text-yellow-700';
      case 'Alto': return 'bg-orange-100 text-orange-700';
      case 'Muito Alto': return 'bg-red-100 text-red-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />

      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 pt-24 pb-12">
        <button
          onClick={() => navigate(-1)}
          className="inline-flex items-center gap-2 text-gray-600 hover:text-primary-600 transition-colors mb-6"
        >
          <ArrowLeft className="w-5 h-5" />
          Voltar
        </button>

        <div className="mb-6">
          <h1 className="text-2xl md:text-3xl font-bold text-gray-900">Identificar Residuo com IA</h1>
          <p className="text-gray-600">Tire uma foto e nossa IA ira identificar automaticamente</p>
        </div>

        {!selectedImage ? (
          <div
            onDrop={handleDrop}
            onDragOver={(e) => e.preventDefault()}
            className="card border-2 border-dashed border-gray-300 hover:border-primary-400 transition-colors"
          >
            <div className="text-center py-12">
              <div className="w-20 h-20 bg-primary-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <Camera className="w-10 h-10 text-primary-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">Capture ou envie uma imagem</h3>
              <p className="text-gray-500 mb-8">Arraste uma imagem ou use os botoes abaixo</p>

              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <label className="btn-primary inline-flex items-center justify-center gap-2 cursor-pointer">
                  <Camera className="w-5 h-5" />
                  Tirar Foto
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    capture="environment"
                    onChange={handleImageCapture}
                    className="hidden"
                  />
                </label>

                <label className="btn-outline inline-flex items-center justify-center gap-2 cursor-pointer">
                  <Upload className="w-5 h-5" />
                  Enviar Imagem
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleImageCapture}
                    className="hidden"
                  />
                </label>
              </div>
            </div>
          </div>
        ) : (
          <div className="space-y-6">
            {/* Image Preview */}
            <div className="card relative overflow-hidden">
              <button
                onClick={resetCapture}
                className="absolute top-4 right-4 z-10 w-10 h-10 bg-black/50 hover:bg-black/70 rounded-full flex items-center justify-center text-white transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
              <img
                src={selectedImage}
                alt="Residuo capturado"
                className="w-full max-h-[400px] object-contain rounded-xl"
              />
            </div>

            {analyzing && (
              <div className="card text-center py-8 animate-pulse">
                <div className="w-16 h-16 bg-gradient-to-br from-primary-400 to-secondary-400 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Sparkles className="w-8 h-8 text-white animate-bounce" />
                </div>
                <h3 className="font-bold text-gray-900 mb-2">Gemini AI analisando...</h3>
                <p className="text-gray-500">Identificando o tipo de residuo na imagem</p>
              </div>
            )}

            {error && (
              <div className="card bg-red-50 border border-red-200">
                <div className="flex items-start gap-3">
                  <AlertTriangle className="w-6 h-6 text-red-500 flex-shrink-0" />
                  <div>
                    <h5 className="font-bold text-red-700 mb-1">Erro na analise</h5>
                    <p className="text-sm text-red-600">{error}</p>
                  </div>
                </div>
              </div>
            )}

            {result && !analyzing && (
              <div className="card animate-scale-in">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2 text-primary-600">
                    <CheckCircle className="w-5 h-5" />
                    <span className="font-medium">Identificado com IA Gemini</span>
                  </div>
                  <span className="text-sm px-3 py-1 bg-primary-100 text-primary-700 rounded-full font-medium">
                    {result.aiResult.confidence}% confianca
                  </span>
                </div>

                <div className={`p-6 rounded-2xl mb-6 ${getColorClasses(result.color).bg} ${getColorClasses(result.color).border} border`}>
                  <div className="flex items-center gap-4">
                    <div className="text-5xl">{result.icon}</div>
                    <div>
                      <h3 className={`text-2xl font-bold ${getColorClasses(result.color).text}`}>
                        {result.type}
                      </h3>
                      <p className="text-sm opacity-70">{result.aiResult.category}</p>
                    </div>
                  </div>
                </div>

                {/* Quick Stats */}
                <div className="grid grid-cols-3 gap-3 mb-6">
                  <div className="bg-gray-50 rounded-xl p-3 text-center">
                    <div className="flex items-center justify-center gap-1 mb-1">
                      <Recycle className={`w-4 h-4 ${result.aiResult.recyclable ? 'text-green-500' : 'text-red-500'}`} />
                      <span className="text-xs text-gray-500">Reciclavel</span>
                    </div>
                    <span className={`font-bold ${result.aiResult.recyclable ? 'text-green-600' : 'text-red-500'}`}>
                      {result.aiResult.recyclable ? 'Sim' : 'Nao'}
                    </span>
                  </div>

                  <div className="bg-gray-50 rounded-xl p-3 text-center">
                    <div className="flex items-center justify-center gap-1 mb-1">
                      <Clock className="w-4 h-4 text-gray-400" />
                      <span className="text-xs text-gray-500">Decomposicao</span>
                    </div>
                    <span className="font-bold text-gray-900 text-sm">{result.aiResult.decompositionTime}</span>
                  </div>

                  <div className="bg-gray-50 rounded-xl p-3 text-center">
                    <div className="flex items-center justify-center gap-1 mb-1">
                      <Gauge className="w-4 h-4 text-gray-400" />
                      <span className="text-xs text-gray-500">Impacto</span>
                    </div>
                    <span className={`font-bold text-sm px-2 py-0.5 rounded-full ${getImpactColor(result.aiResult.environmentalImpact)}`}>
                      {result.aiResult.environmentalImpact}
                    </span>
                  </div>
                </div>

                <div className="space-y-6">
                  <div>
                    <h4 className="flex items-center gap-2 font-bold text-gray-900 mb-3">
                      <Recycle className="w-5 h-5 text-primary-500" />
                      Como descartar
                    </h4>
                    <p className="text-gray-600 leading-relaxed">{result.disposal}</p>
                  </div>

                  <div>
                    <h4 className="flex items-center gap-2 font-bold text-gray-900 mb-3">
                      <MapPin className="w-5 h-5 text-secondary-500" />
                      Pontos de coleta
                    </h4>
                    <div className="flex flex-wrap gap-2">
                      {result.points.map((point, index) => (
                        <span
                          key={index}
                          className="px-3 py-1 bg-gray-100 rounded-full text-sm text-gray-700"
                        >
                          {point}
                        </span>
                      ))}
                    </div>
                  </div>

                  {result.aiResult.caresNeeded && (
                    <div className="flex items-start gap-3 p-4 bg-amber-50 border border-amber-200 rounded-xl">
                      <AlertTriangle className="w-6 h-6 text-amber-500 flex-shrink-0" />
                      <div>
                        <h5 className="font-bold text-amber-700 mb-1">Cuidados necessarios</h5>
                        <p className="text-sm text-amber-600">{result.aiResult.caresNeeded}</p>
                      </div>
                    </div>
                  )}

                  {(result.color === 'red' || result.aiResult.environmentalImpact === 'Muito Alto') && (
                    <div className="flex items-start gap-3 p-4 bg-red-50 border border-red-200 rounded-xl">
                      <AlertTriangle className="w-6 h-6 text-red-500 flex-shrink-0" />
                      <div>
                        <h5 className="font-bold text-red-700 mb-1">Atencao!</h5>
                        <p className="text-sm text-red-600">
                          Este tipo de residuo requer atencao especial. Nao descarte no lixo comum.
                        </p>
                      </div>
                    </div>
                  )}

                  {result.aiResult.recyclable && (
                    <div className="flex items-start gap-3 p-4 bg-primary-50 border border-primary-200 rounded-xl">
                      <Leaf className="w-6 h-6 text-primary-500 flex-shrink-0" />
                      <div>
                        <h5 className="font-bold text-primary-700 mb-1">Otimo trabalho!</h5>
                        <p className="text-sm text-primary-600">
                          Voce esta contribuindo para um mundo mais sustentavel. Continue assim!
                        </p>
                      </div>
                    </div>
                  )}
                </div>

                <div className="mt-6 flex gap-3">
                  <button onClick={resetCapture} className="btn-outline flex-1">
                    Nova identificacao
                  </button>
                  <button
                    onClick={() => navigate('/collection-points?category=' + encodeURIComponent(result.aiResult.category))}
                    className="btn-secondary flex-1"
                  >
                    Ver Pontos de Coleta
                  </button>
                </div>
              </div>
            )}

            {!analyzing && !result && !error && (
              <button
                onClick={analyzeImage}
                className="btn-primary w-full text-lg py-4 flex items-center justify-center gap-2"
              >
                <Sparkles className="w-5 h-5" />
                Analisar com IA Gemini
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
