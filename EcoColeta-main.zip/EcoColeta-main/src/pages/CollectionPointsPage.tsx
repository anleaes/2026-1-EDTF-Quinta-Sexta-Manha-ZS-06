import { useEffect, useState } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { ArrowLeft, MapPin, Clock, Phone, Filter, Navigation, ExternalLink } from 'lucide-react';
import Navbar from '../components/Navbar';

interface CollectionPoint {
  id: string;
  name: string;
  address: string;
  latitude: number;
  longitude: number;
  opening_hours: string;
  phone: string;
  waste_categories: string[];
  distance?: number;
}

const CATEGORY_ICONS: Record<string, string> = {
  'Plastico': '♻️',
  'Papel': '📄',
  'Metal': '🥫',
  'Vidro': '🍾',
  'Organico': '🍃',
  'Eletronico': '📱',
  'Bateria': '🔋',
  'Oleo': '🫗',
  'Farmaceutico': '💊',
};

const CATEGORY_COLORS: Record<string, string> = {
  'Plastico': 'bg-blue-100 text-blue-700',
  'Papel': 'bg-blue-100 text-blue-700',
  'Metal': 'bg-yellow-100 text-yellow-700',
  'Vidro': 'bg-green-100 text-green-700',
  'Organico': 'bg-amber-100 text-amber-700',
  'Eletronico': 'bg-gray-100 text-gray-700',
  'Bateria': 'bg-red-100 text-red-700',
  'Oleo': 'bg-yellow-100 text-yellow-700',
  'Farmaceutico': 'bg-red-100 text-red-700',
};

export default function CollectionPointsPage() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const categoryFilter = searchParams.get('category') || '';

  const [points, setPoints] = useState<CollectionPoint[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState(categoryFilter);
  const [selectedPoint, setSelectedPoint] = useState<CollectionPoint | null>(null);
  const [showFilters, setShowFilters] = useState(false);

  useEffect(() => {
    fetchPoints();
  }, [selectedCategory]);

  async function fetchPoints() {
    try {
      let query = supabase.from('collection_points').select('*');

      if (selectedCategory) {
        query = query.contains('waste_categories', [selectedCategory]);
      }

      const { data, error } = await query;

      if (error) throw error;

      // Calculate mock distances (in real app, would use user location)
      const pointsWithDistance = (data || []).map(point => ({
        ...point,
        distance: Math.random() * 10 + 0.5,
      })).sort((a, b) => a.distance - b.distance);

      setPoints(pointsWithDistance);
    } catch (err) {
      console.error('Error fetching collection points:', err);
    } finally {
      setLoading(false);
    }
  }

  const allCategories = [
    'Plastico', 'Papel', 'Metal', 'Vidro', 'Organico',
    'Eletronico', 'Bateria', 'Oleo', 'Farmaceutico'
  ];

  const openMaps = (point: CollectionPoint) => {
    const url = `https://www.google.com/maps/search/?api=1&query=${point.latitude},${point.longitude}`;
    window.open(url, '_blank');
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        <div className="pt-24 flex items-center justify-center">
          <div className="w-8 h-8 border-4 border-primary-500 border-t-transparent rounded-full animate-spin" />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-24 pb-12">
        <button
          onClick={() => navigate(-1)}
          className="inline-flex items-center gap-2 text-gray-600 hover:text-primary-600 transition-colors mb-6"
        >
          <ArrowLeft className="w-5 h-5" />
          Voltar
        </button>

        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
          <div>
            <h1 className="text-2xl md:text-3xl font-bold text-gray-900">Pontos de Coleta</h1>
            <p className="text-gray-600">Encontre locais para descarte adequado</p>
          </div>

          <button
            onClick={() => setShowFilters(!showFilters)}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl border-2 transition-colors ${showFilters ? 'border-primary-500 bg-primary-50 text-primary-600' : 'border-gray-200 text-gray-600 hover:border-gray-300'}`}
          >
            <Filter className="w-5 h-5" />
            Filtrar por categoria
          </button>
        </div>

        {/* Category Filters */}
        {showFilters && (
          <div className="card mb-6 animate-slide-up">
            <h3 className="font-medium text-gray-700 mb-3">Selecione a categoria:</h3>
            <div className="flex flex-wrap gap-2">
              <button
                onClick={() => setSelectedCategory('')}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${!selectedCategory ? 'bg-primary-500 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}
              >
                Todas
              </button>
              {allCategories.map(cat => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-4 py-2 rounded-full text-sm font-medium transition-all flex items-center gap-1 ${selectedCategory === cat ? 'bg-primary-500 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}
                >
                  <span>{CATEGORY_ICONS[cat]}</span>
                  {cat}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Map Placeholder */}
        <div className="card mb-6 overflow-hidden">
          <div className="bg-gradient-to-br from-primary-100 to-secondary-100 h-64 md:h-80 rounded-xl flex items-center justify-center relative">
            <div className="absolute inset-0 opacity-30">
              <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
                <pattern id="grid" width="10" height="10" patternUnits="userSpaceOnUse">
                  <path d="M 10 0 L 0 0 0 10" fill="none" stroke="currentColor" strokeWidth="0.5" className="text-primary-300" />
                </pattern>
                <rect width="100" height="100" fill="url(#grid)" />
              </svg>
            </div>
            <div className="text-center relative z-10">
              <MapPin className="w-12 h-12 text-primary-500 mx-auto mb-3" />
              <p className="text-gray-600 font-medium">Mapa interativo</p>
              <p className="text-sm text-gray-400">{points.length} pontos encontrados</p>
            </div>

            {/* Point markers preview */}
            <div className="absolute inset-4 pointer-events-none">
              {points.slice(0, 5).map((point, index) => (
                <div
                  key={point.id}
                  className="absolute w-8 h-8 bg-primary-500 rounded-full flex items-center justify-center shadow-lg cursor-pointer hover:scale-110 transition-transform pointer-events-auto"
                  style={{
                    top: `${20 + (index * 15) % 60}%`,
                    left: `${15 + (index * 20) % 70}%`,
                  }}
                  onClick={() => setSelectedPoint(point)}
                >
                  <MapPin className="w-4 h-4 text-white" />
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Points List */}
        <div className="space-y-4">
          {points.length === 0 ? (
            <div className="card text-center py-12">
              <MapPin className="w-12 h-12 text-gray-300 mx-auto mb-4" />
              <h3 className="font-medium text-gray-900 mb-2">Nenhum ponto encontrado</h3>
              <p className="text-gray-500">Tente selecionar outra categoria</p>
            </div>
          ) : (
            points.map(point => (
              <div
                key={point.id}
                className={`card hover:shadow-lg transition-shadow cursor-pointer ${selectedPoint?.id === point.id ? 'ring-2 ring-primary-500' : ''}`}
                onClick={() => setSelectedPoint(point)}
              >
                <div className="flex flex-col md:flex-row gap-4">
                  <div className="flex-1">
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <h3 className="font-bold text-gray-900 text-lg">{point.name}</h3>
                        <div className="flex items-center gap-1 text-gray-600 mt-1">
                          <Navigation className="w-4 h-4 text-primary-500" />
                          <span className="text-sm">{point.distance?.toFixed(1)} km de voce</span>
                        </div>
                      </div>
                      <button
                        onClick={(e) => { e.stopPropagation(); openMaps(point); }}
                        className="p-2 bg-primary-100 rounded-lg hover:bg-primary-200 transition-colors"
                      >
                        <ExternalLink className="w-5 h-5 text-primary-600" />
                      </button>
                    </div>

                    <div className="flex items-start gap-2 text-gray-600 mb-3">
                      <MapPin className="w-4 h-4 mt-1 flex-shrink-0" />
                      <span className="text-sm">{point.address}</span>
                    </div>

                    <div className="flex items-center gap-4 text-sm text-gray-500 mb-3">
                      {point.opening_hours && (
                        <div className="flex items-center gap-1">
                          <Clock className="w-4 h-4" />
                          <span>{point.opening_hours}</span>
                        </div>
                      )}
                      {point.phone && (
                        <div className="flex items-center gap-1">
                          <Phone className="w-4 h-4" />
                          <span>{point.phone}</span>
                        </div>
                      )}
                    </div>

                    <div className="flex flex-wrap gap-2">
                      {point.waste_categories.map(cat => (
                        <span
                          key={cat}
                          className={`px-3 py-1 rounded-full text-xs font-medium flex items-center gap-1 ${CATEGORY_COLORS[cat] || 'bg-gray-100 text-gray-600'}`}
                        >
                          <span>{CATEGORY_ICONS[cat]}</span>
                          {cat}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Selected Point Detail */}
        {selectedPoint && (
          <div className="fixed bottom-0 inset-x-0 bg-white border-t shadow-2xl p-4 md:hidden animate-slide-up rounded-t-2xl">
            <div className="max-w-md mx-auto">
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-bold text-gray-900">{selectedPoint.name}</h3>
                <button
                  onClick={() => setSelectedPoint(null)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  X
                </button>
              </div>
              <p className="text-sm text-gray-600 mb-3">{selectedPoint.address}</p>
              <button
                onClick={() => openMaps(selectedPoint)}
                className="w-full btn-primary"
              >
                Abrir no Google Maps
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
