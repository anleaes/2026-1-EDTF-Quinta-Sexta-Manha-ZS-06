import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import { Camera, Trash2, TreePine, TrendingUp, Clock, Recycle, ChevronRight, Sparkles } from 'lucide-react';
import Navbar from '../components/Navbar';

interface WasteIdentification {
  id: string;
  image_url: string;
  waste_type: string;
  disposal_instructions: string;
  created_at: string;
}

interface Profile {
  name: string;
}

export default function DashboardPage() {
  const { user } = useAuth();
  const [profile, setProfile] = useState<Profile | null>(null);
  const [identifications, setIdentifications] = useState<WasteIdentification[]>([]);
  const [stats, setStats] = useState({ total: 0, recyclable: 0, organic: 0, hazardous: 0 });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchData() {
      if (!user) return;

      try {
        // Fetch profile
        const { data: profileData } = await supabase
          .from('profiles')
          .select('name')
          .eq('user_id', user.id)
          .single();

        setProfile(profileData);

        // Fetch identifications
        const { data: identificationsData } = await supabase
          .from('waste_identifications')
          .select('*')
          .eq('user_id', user.id)
          .order('created_at', { ascending: false })
          .limit(10);

        if (identificationsData) {
          setIdentifications(identificationsData);
          const total = identificationsData.length;
          const recyclable = identificationsData.filter(i => i.waste_type?.toLowerCase().includes('recic')).length;
          const organic = identificationsData.filter(i => i.waste_type?.toLowerCase().includes('organ')).length;
          const hazardous = identificationsData.filter(i => i.waste_type?.toLowerCase().includes('perig')).length;
          setStats({ total, recyclable, organic, hazardous });
        }
      } catch (error) {
        console.error('Error fetching data:', error);
      } finally {
        setLoading(false);
      }
    }

    fetchData();
  }, [user]);

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: 'short',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Bom dia';
    if (hour < 18) return 'Boa tarde';
    return 'Boa noite';
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        <div className="pt-24 flex items-center justify-center">
          <div className="w-8 h-8 border-4 border-primary-500 border-t-transparent rounded-full animate-spin" />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-24 pb-12">
        {/* Welcome Section */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <Sparkles className="w-6 h-6 text-primary-500" />
            <h1 className="text-2xl md:text-3xl font-bold text-gray-900">
              {getGreeting()}, {profile?.name || user?.email?.split('@')[0]}!
            </h1>
          </div>
          <p className="text-gray-600">Continue sua jornada sustentavel. Cada acao conta!</p>
        </div>

        {/* Quick Action Card */}
        <div className="mb-8">
          <Link
            to="/identify"
            className="block w-full bg-gradient-to-r from-primary-500 to-secondary-500 rounded-2xl p-6 md:p-8 text-white hover:shadow-xl hover:shadow-primary-500/20 transition-all duration-300 group"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 bg-white/20 rounded-2xl flex items-center justify-center">
                  <Camera className="w-7 h-7" />
                </div>
                <div>
                  <h2 className="text-xl md:text-2xl font-bold mb-1">Identificar Residuo</h2>
                  <p className="text-white/80">Tire uma foto e descubra a forma correta de descarte</p>
                </div>
              </div>
              <ChevronRight className="w-6 h-6 group-hover:translate-x-1 transition-transform" />
            </div>
          </Link>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <div className="card flex items-center gap-4">
            <div className="w-12 h-12 bg-primary-100 rounded-xl flex items-center justify-center">
              <Trash2 className="w-6 h-6 text-primary-600" />
            </div>
            <div>
              <div className="text-2xl font-bold text-gray-900">{stats.total}</div>
              <div className="text-sm text-gray-500">Identificacoes</div>
            </div>
          </div>

          <div className="card flex items-center gap-4">
            <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
              <Recycle className="w-6 h-6 text-blue-600" />
            </div>
            <div>
              <div className="text-2xl font-bold text-gray-900">{stats.recyclable}</div>
              <div className="text-sm text-gray-500">Reciclaveis</div>
            </div>
          </div>

          <div className="card flex items-center gap-4">
            <div className="w-12 h-12 bg-amber-100 rounded-xl flex items-center justify-center">
              <TreePine className="w-6 h-6 text-amber-600" />
            </div>
            <div>
              <div className="text-2xl font-bold text-gray-900">{Math.floor(stats.total * 0.5)}</div>
              <div className="text-sm text-gray-500">Arvores salvas</div>
            </div>
          </div>

          <div className="card flex items-center gap-4">
            <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center">
              <TrendingUp className="w-6 h-6 text-green-600" />
            </div>
            <div>
              <div className="text-2xl font-bold text-gray-900">{stats.total * 2}kg</div>
              <div className="text-sm text-gray-500">CO2 evitado</div>
            </div>
          </div>
        </div>

        {/* Impact Message */}
        {stats.total > 0 && (
          <div className="bg-gradient-to-r from-primary-50 to-secondary-50 rounded-2xl p-6 mb-8 border border-primary-100">
            <div className="flex items-start gap-4">
              <div className="w-10 h-10 bg-primary-500 rounded-full flex items-center justify-center flex-shrink-0">
                <span className="text-xl">🌱</span>
              </div>
              <div>
                <h3 className="font-bold text-gray-900 mb-1">Continue assim!</h3>
                <p className="text-gray-600 text-sm">
                  Voce ja fez {stats.total} identificacoes. Sua contribuicao ajuda a preservar o meio ambiente
                  e inspirar outras pessoas a descartarem corretamente.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Recent History */}
        <div className="card">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold text-gray-900">Historico Recente</h2>
            {identifications.length > 0 && (
              <Link to="/history" className="text-primary-600 font-medium hover:text-primary-700 flex items-center gap-1">
                Ver todos <ChevronRight className="w-4 h-4" />
              </Link>
            )}
          </div>

          {identifications.length === 0 ? (
            <div className="text-center py-12">
              <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Camera className="w-8 h-8 text-gray-400" />
              </div>
              <h3 className="font-medium text-gray-900 mb-2">Nenhuma identificacao ainda</h3>
              <p className="text-gray-500 mb-4">Comece identificando seu primeiro residuo!</p>
              <Link to="/identify" className="btn-primary inline-flex items-center gap-2">
                <Camera className="w-5 h-5" />
                Identificar Residuo
              </Link>
            </div>
          ) : (
            <div className="space-y-3">
              {identifications.map((item) => (
                <div
                  key={item.id}
                  className="flex items-center gap-4 p-4 bg-gray-50 rounded-xl hover:bg-gray-100 transition-colors"
                >
                  <div className="w-14 h-14 bg-primary-100 rounded-xl flex items-center justify-center flex-shrink-0">
                    <Recycle className="w-7 h-7 text-primary-600" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="font-medium text-gray-900 truncate">{item.waste_type}</div>
                    <div className="text-sm text-gray-500 truncate">{item.disposal_instructions}</div>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-gray-400 flex-shrink-0">
                    <Clock className="w-4 h-4" />
                    {formatDate(item.created_at)}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
