import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import {
  ArrowLeft, User as UserIcon, Mail, Calendar, Settings, Leaf, Trash2, TreePine,
  TrendingUp, BarChart3, LogOut, Edit2, Camera, Save, ChevronRight
} from 'lucide-react';
import Navbar from '../components/Navbar';

interface Profile {
  name: string;
  avatar_url: string;
  created_at: string;
}

interface UserStats {
  totalIdentifications: number;
  recyclable: number;
  treesSaved: number;
  co2Avoided: number;
  monthlyData: { month: string; count: number }[];
}

const MONTHS_PT = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];

export default function ProfilePage() {
  const navigate = useNavigate();
  const { user, signOut } = useAuth();
  const [profile, setProfile] = useState<Profile | null>(null);
  const [stats, setStats] = useState<UserStats>({
    totalIdentifications: 0,
    recyclable: 0,
    treesSaved: 0,
    co2Avoided: 0,
    monthlyData: [],
  });
  const [editing, setEditing] = useState(false);
  const [editName, setEditName] = useState('');
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (user) {
      fetchProfile();
      fetchStats();
    }
  }, [user]);

  async function fetchProfile() {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('user_id', user?.id)
        .single();

      if (error) throw error;
      setProfile(data);
      setEditName(data?.name || '');
    } catch (err) {
      console.error('Error fetching profile:', err);
    } finally {
      setLoading(false);
    }
  }

  async function fetchStats() {
    try {
      const { data: identifications, error } = await supabase
        .from('waste_identifications')
        .select('waste_type, created_at')
        .eq('user_id', user?.id);

      if (error) throw error;

      if (identifications) {
        const recyclableKeywords = ['reciclavel', 'recicl', 'plastico', 'papel', 'metal', 'vidro'];
        const recyclable = identifications.filter(i =>
          recyclableKeywords.some(k => i.waste_type?.toLowerCase().includes(k))
        ).length;

        const monthlyCounts: Record<string, number> = {};
        const currentYear = new Date().getFullYear();

        identifications.forEach(item => {
          const date = new Date(item.created_at);
          if (date.getFullYear() === currentYear) {
            const monthName = MONTHS_PT[date.getMonth()];
            monthlyCounts[monthName] = (monthlyCounts[monthName] || 0) + 1;
          }
        });

        const monthlyData = MONTHS_PT.map(month => ({
          month,
          count: monthlyCounts[month] || 0,
        }));

        setStats({
          totalIdentifications: identifications.length,
          recyclable,
          treesSaved: Math.floor(recyclable * 0.5),
          co2Avoided: identifications.length * 2,
          monthlyData,
        });
      }
    } catch (err) {
      console.error('Error fetching stats:', err);
    }
  }

  async function handleSaveProfile() {
    if (!editName.trim()) return;

    setSaving(true);
    try {
      const { error } = await supabase
        .from('profiles')
        .update({ name: editName.trim(), updated_at: new Date().toISOString() })
        .eq('user_id', user?.id);

      if (error) throw error;

      setProfile(prev => prev ? { ...prev, name: editName.trim() } : null);
      setEditing(false);
    } catch (err) {
      console.error('Error saving profile:', err);
    } finally {
      setSaving(false);
    }
  }

  async function handleSignOut() {
    await signOut();
    navigate('/');
  }

  const formatMemberSince = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('pt-BR', {
      month: 'long',
      year: 'numeric',
    });
  };

  const maxMonthlyCount = Math.max(...stats.monthlyData.map(d => d.count), 1);

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        <div className="pt-24 flex items-center justify-center">
          <div className="w-8 h-8 border-4 border-primary-500 border-t-transparent rounded-full animate-spin" />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 pt-24 pb-12">
        <button
          onClick={() => navigate(-1)}
          className="inline-flex items-center gap-2 text-gray-600 hover:text-primary-600 transition-colors mb-6"
        >
          <ArrowLeft className="w-5 h-5" />
          Voltar
        </button>

        {/* Profile Header */}
        <div className="card mb-6">
          <div className="flex flex-col md:flex-row items-center gap-6">
            <div className="relative">
              <div className="w-24 h-24 bg-gradient-to-br from-primary-400 to-primary-600 rounded-full flex items-center justify-center shadow-lg">
                {profile?.avatar_url ? (
                  <img
                    src={profile.avatar_url}
                    alt="Avatar"
                    className="w-full h-full rounded-full object-cover"
                  />
                ) : (
                  <UserIcon className="w-12 h-12 text-white" />
                )}
              </div>
              <button className="absolute bottom-0 right-0 w-8 h-8 bg-white rounded-full shadow-lg flex items-center justify-center hover:bg-gray-50 transition-colors">
                <Camera className="w-4 h-4 text-gray-600" />
              </button>
            </div>

            <div className="flex-1 text-center md:text-left">
              {editing ? (
                <div className="flex flex-col sm:flex-row gap-2 items-center">
                  <input
                    type="text"
                    value={editName}
                    onChange={(e) => setEditName(e.target.value)}
                    className="input-field text-lg font-bold text-center md:text-left"
                    placeholder="Seu nome"
                  />
                  <div className="flex gap-2">
                    <button
                      onClick={handleSaveProfile}
                      disabled={saving}
                      className="btn-primary flex items-center gap-1"
                    >
                      <Save className="w-4 h-4" />
                      {saving ? 'Salvando...' : 'Salvar'}
                    </button>
                    <button
                      onClick={() => {
                        setEditing(false);
                        setEditName(profile?.name || '');
                      }}
                      className="btn-outline"
                    >
                      Cancelar
                    </button>
                  </div>
                </div>
              ) : (
                <div className="flex items-center gap-2 justify-center md:justify-start">
                  <h1 className="text-2xl font-bold text-gray-900">{profile?.name || 'Usuario'}</h1>
                  <button
                    onClick={() => setEditing(true)}
                    className="p-1 hover:bg-gray-100 rounded-lg transition-colors"
                  >
                    <Edit2 className="w-4 h-4 text-gray-400" />
                  </button>
                </div>
              )}

              <div className="flex items-center gap-1 text-gray-500 mt-1 justify-center md:justify-start">
                <Mail className="w-4 h-4" />
                <span className="text-sm">{user?.email}</span>
              </div>

              {profile?.created_at && (
                <div className="flex items-center gap-1 text-gray-400 mt-2 justify-center md:justify-start">
                  <Calendar className="w-4 h-4" />
                  <span className="text-sm">Membro desde {formatMemberSince(profile.created_at)}</span>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Environmental Impact Stats */}
        <div className="card mb-6">
          <h2 className="font-bold text-gray-900 mb-4 flex items-center gap-2 text-lg">
            <Leaf className="w-5 h-5 text-primary-500" />
            Seu Impacto Ambiental
          </h2>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-primary-50 rounded-xl p-4 text-center">
              <Trash2 className="w-8 h-8 text-primary-500 mx-auto mb-2" />
              <div className="text-2xl font-bold text-gray-900">{stats.totalIdentifications}</div>
              <div className="text-xs text-gray-500">Identificacoes</div>
            </div>

            <div className="bg-green-50 rounded-xl p-4 text-center">
              <TreePine className="w-8 h-8 text-green-500 mx-auto mb-2" />
              <div className="text-2xl font-bold text-green-600">{stats.treesSaved}</div>
              <div className="text-xs text-gray-500">Arvores salvas</div>
            </div>

            <div className="bg-secondary-50 rounded-xl p-4 text-center">
              <TrendingUp className="w-8 h-8 text-secondary-500 mx-auto mb-2" />
              <div className="text-2xl font-bold text-secondary-600">{stats.co2Avoided}kg</div>
              <div className="text-xs text-gray-500">CO2 evitado</div>
            </div>

            <div className="bg-blue-50 rounded-xl p-4 text-center">
              <BarChart3 className="w-8 h-8 text-blue-500 mx-auto mb-2" />
              <div className="text-2xl font-bold text-blue-600">
                {stats.totalIdentifications > 0 ? Math.round((stats.recyclable / stats.totalIdentifications) * 100) : 0}%
              </div>
              <div className="text-xs text-gray-500">Taxa reciclagem</div>
            </div>
          </div>

          {/* Monthly Chart */}
          {stats.totalIdentifications > 0 && (
            <div className="mt-6">
              <h3 className="text-sm font-medium text-gray-600 mb-3">Atividade em {new Date().getFullYear()}</h3>
              <div className="flex items-end gap-1 h-24">
                {stats.monthlyData.map((data, index) => (
                  <div key={index} className="flex-1 flex flex-col items-center gap-1">
                    <div
                      className="w-full bg-gradient-to-t from-primary-400 to-primary-500 rounded-t-sm transition-all duration-300 hover:from-primary-500 hover:to-primary-600"
                      style={{ height: `${(data.count / maxMonthlyCount) * 100}%`, minHeight: data.count > 0 ? '8px' : '2px' }}
                      title={`${data.count} identificacoes`}
                    />
                    <span className="text-xs text-gray-400">{data.month}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Quick Actions */}
        <div className="card mb-6">
          <h2 className="font-bold text-gray-900 mb-4 flex items-center gap-2 text-lg">
            <Settings className="w-5 h-5 text-gray-500" />
            Configuracoes e navegacao
          </h2>

          <div className="space-y-2">
            <button
              onClick={() => navigate('/identify')}
              className="w-full flex items-center justify-between p-4 bg-gray-50 hover:bg-gray-100 rounded-xl transition-colors"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-primary-100 rounded-lg flex items-center justify-center">
                  <Camera className="w-5 h-5 text-primary-600" />
                </div>
                <div className="text-left">
                  <div className="font-medium text-gray-900">Identificar Residuo</div>
                  <div className="text-sm text-gray-500">Tire uma foto e descubra</div>
                </div>
              </div>
              <ChevronRight className="w-5 h-5 text-gray-400" />
            </button>

            <button
              onClick={() => navigate('/history')}
              className="w-full flex items-center justify-between p-4 bg-gray-50 hover:bg-gray-100 rounded-xl transition-colors"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-secondary-100 rounded-lg flex items-center justify-center">
                  <BarChart3 className="w-5 h-5 text-secondary-600" />
                </div>
                <div className="text-left">
                  <div className="font-medium text-gray-900">Historico</div>
                  <div className="text-sm text-gray-500">{stats.totalIdentifications} identificacoes</div>
                </div>
              </div>
              <ChevronRight className="w-5 h-5 text-gray-400" />
            </button>

            <button
              onClick={() => navigate('/collection-points')}
              className="w-full flex items-center justify-between p-4 bg-gray-50 hover:bg-gray-100 rounded-xl transition-colors"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                  <Leaf className="w-5 h-5 text-green-600" />
                </div>
                <div className="text-left">
                  <div className="font-medium text-gray-900">Pontos de Coleta</div>
                  <div className="text-sm text-gray-500">Encontre locais proximos</div>
                </div>
              </div>
              <ChevronRight className="w-5 h-5 text-gray-400" />
            </button>
          </div>
        </div>

        {/* Sign Out */}
        <button
          onClick={handleSignOut}
          className="w-full flex items-center justify-center gap-2 p-4 bg-red-50 hover:bg-red-100 rounded-xl text-red-600 font-medium transition-colors"
        >
          <LogOut className="w-5 h-5" />
          Sair da conta
        </button>
      </div>
    </div>
  );
}
