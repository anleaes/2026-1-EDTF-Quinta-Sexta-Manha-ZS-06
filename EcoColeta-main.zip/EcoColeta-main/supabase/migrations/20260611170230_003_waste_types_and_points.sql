-- Create waste_types table with comprehensive information
CREATE TABLE waste_types (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  category TEXT NOT NULL,
  description TEXT,
  correct_disposal TEXT NOT NULL,
  recyclable BOOLEAN DEFAULT false,
  decomposition_time TEXT,
  environmental_impact TEXT DEFAULT 'Baixo',
  cares_needed TEXT,
  icon TEXT DEFAULT '♻️',
  color TEXT DEFAULT 'blue',
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Create collection_points table
CREATE TABLE collection_points (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  address TEXT NOT NULL,
  latitude DECIMAL(10, 8),
  longitude DECIMAL(11, 8),
  opening_hours TEXT,
  phone TEXT,
  waste_categories TEXT[] NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Enable RLS
ALTER TABLE waste_types ENABLE ROW LEVEL SECURITY;
ALTER TABLE collection_points ENABLE ROW LEVEL SECURITY;

-- Waste types policies (public read)
CREATE POLICY "waste_types_public_read" ON waste_types FOR SELECT
  TO public USING (true);

-- Collection points policies (public read)
CREATE POLICY "collection_points_public_read" ON collection_points FOR SELECT
  TO public USING (true);

-- Insert waste types data
INSERT INTO waste_types (name, category, description, correct_disposal, recyclable, decomposition_time, environmental_impact, cares_needed, icon, color) VALUES
('Garrafa PET', 'Plastico', 'Garrafas de polietileno tereftalato usadas para bebidas e alimentos', 'Descarte em lixeiras azuis de reciclagem. Remova tampas e lave antes de descartar. Amasse para economizar espaco.', true, '450 anos', 'Alto', 'Lavar antes de descartar. Remover etiquetas plastificadas.', '♻️', 'blue'),
('Papelao', 'Papel', 'Caixas e embalagens de papelao ondulado', 'Descarte em lixeiras azuis. Mantenha seco e limpo. Desmonte as caixas.', true, '2-5 meses', 'Baixo', 'Manter seco. Remover fitas adesivas.', '📦', 'blue'),
('Lata de Aluminio', 'Metal', 'Latas de bebidas e alimentos', 'Descarte em lixeiras amarelas. Lave antes de descartar. Amasse para economizar espaco.', true, '200-500 anos', 'Alto', 'Lavar para evitar odores.', '🥫', 'yellow'),
('Vidro de Garrafa', 'Vidro', 'Garrafas e frascos de vidro', 'Descarte em lixeiras verdes. Se estiver quebrado, envolva em papel jornal.', true, '4000 anos', 'Alto', 'Cuidado com cacos quebrados. Envolva em papel.', '🍾', 'green'),
('Restos de Comida', 'Organico', 'Restos de alimentos e residuos organicos', 'Descarte em lixeiras marrons. Ideal para composteira caseira ou comunitaria.', false, '1-6 meses', 'Medio', 'Evitar misturar com oleo ou produtos quimicos.', '🍃', 'brown'),
('Celular', 'Eletronico', 'Dispositivos moveis e smartphones', 'Nao descarte no lixo comum! Leve a pontos de coleta de e-lixo.', true, 'Indeterminado', 'Muito Alto', 'Remova dados pessoais. Bateria precisa de cuidado especial.', '📱', 'gray'),
('Pilha Comum', 'Bateria', 'Pilhas alcalinas e de carvao-zinco', 'Nao descarte no lixo comum! Leve a pontos de coleta especificos.', false, 'Indeterminado', 'Muito Alto', 'Contem metais pesados. Manter longe de criancas.', '🔋', 'red'),
('Oleo de Cozinha', 'Oleo', 'Oleo vegetal usado em frituras', 'Nao jogue na pia! Armazene em garrafa e leve a pontos de coleta.', true, 'Indeterminado', 'Alto', 'Armazenar em recipiente fechado. Um litro contamina mil litros de agua.', '🫗', 'yellow'),
('Medicamento Vencido', 'Farmaceutico', 'Remedios e medicamentos fora de validade', 'Nao jogue no lixo ou pia! Leve a farmacias ou postos de coleta.', false, 'Indeterminado', 'Alto', 'Manter na embalagem original se possivel.', '💊', 'red'),
('Lampada Fluorescente', 'Eletronico', 'Lampadas fluorescentes e LED', 'Descarte em pontos especificos. Nao quebre - contem mercurio.', false, 'Indeterminado', 'Alto', 'Se quebrar, nao toque direto. Use luvas.', '💡', 'gray'),
('Eletrodomestico', 'Eletronico', 'Geladeiras, maquinas de lavar, microondas', 'Leve a pontos de coleta ou troque na compra de novo.', true, 'Indeterminado', 'Alto', 'Verifique programas de troca em lojas.', '🔌', 'gray'),
('Isopor', 'Plastico', 'Embalagens de poliestireno expandido', 'Alguns locais aceitam. Dificil de reciclar. Prefira evitar.', false, '50-500 anos', 'Alto', 'Verifique pontos especificos de coleta.', '🧊', 'blue'),
('Pneu', 'Borracha', 'Pneus de veiculos', 'Nao descarte em lixo comum. Leve a borracharias ou pontos de coleta.', false, 'Indeterminado', 'Alto', 'Pode ser reutilizado em artesanato ou queimado para energia.', '🛞', 'black'),
('Papel Higinico Usado', 'Papel', 'Papel higinico, lencos e papel toalha usados', 'Descarte no lixo organico ou comum. Nao reciclavel.', false, '2-4 semanas', 'Baixo', 'Possivel descarga em alguns sistemas de tratamento.', '🧻', 'brown');

-- Insert sample collection points
INSERT INTO collection_points (name, address, latitude, longitude, opening_hours, phone, waste_categories) VALUES
('ECO Ponto Centro', 'Rua das Flores, 123 - Centro', -23.5505, -46.6333, 'Seg-Sex: 8h-18h, Sab: 8h-12h', '(11) 3333-4444', ARRAY['Plastico', 'Papel', 'Metal', 'Vidro']),
('Ponto de Coleta Seletiva Zona Sul', 'Av. Santo Amaro, 1500', -23.6200, -46.6600, 'Seg-Dom: 7h-19h', '(11) 5555-6666', ARRAY['Plastico', 'Papel', 'Metal', 'Vidro', 'Organico']),
('Centro de Reciclagem Norte', 'Rua Voluntarios da Patria, 800', -23.4800, -46.6300, 'Seg-Sex: 6h-20h', '(11) 2222-3333', ARRAY['Eletronico', 'Bateria', 'Oleo']),
('Coleta de E-lixo Tech', 'Av. Paulista, 2000', -23.5629, -46.6544, 'Seg-Sab: 9h-18h', '(11) 9999-8888', ARRAY['Eletronico', 'Bateria']),
('Ponto Organico Vila Mariana', 'Rua Domingos de Morais, 500', -23.6100, -46.6500, 'Todos os dias: 6h-22h', '(11) 7777-6666', ARRAY['Organico']),
('Posto de Coleta Farmaceutica', 'Av. Brasil, 3000', -23.5400, -46.6200, 'Seg-Sex: 8h-17h', '(11) 4444-5555', ARRAY['Farmaceutico']),
('Reciclagem Zona Leste', 'Av. Aguia de Haia, 2000', -23.5700, -46.5000, 'Seg-Sab: 7h-17h', '(11) 8888-7777', ARRAY['Plastico', 'Papel', 'Metal', 'Vidro', 'Eletronico']),
('Ponto Verde Pinheiros', 'Rua dos Pinheiros, 1200', -23.5670, -46.6900, 'Seg-Dom: 8h-20h', '(11) 6666-5555', ARRAY['Plastico', 'Papel', 'Metal', 'Vidro', 'Organico', 'Oleo']);