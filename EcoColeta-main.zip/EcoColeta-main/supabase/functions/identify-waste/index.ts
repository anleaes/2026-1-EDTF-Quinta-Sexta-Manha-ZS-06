import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface WasteIdentification {
  name: string;
  category: string;
  recyclable: boolean;
  decompositionTime: string;
  environmentalImpact: "Baixo" | "Medio" | "Alto" | "Muito Alto";
  correctDisposal: string;
  caresNeeded: string;
  confidence: number;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  if (req.method !== "POST") {
    return new Response(
      JSON.stringify({ error: "Method not allowed" }),
      { status: 405, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }

  try {
    const GEMINI_API_KEY = Deno.env.get("GEMINI_API_KEY");

    if (!GEMINI_API_KEY) {
      return new Response(
        JSON.stringify({ error: "Gemini API key not configured" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const body = await req.json();
    const { image } = body;

    if (!image) {
      return new Response(
        JSON.stringify({ error: "Image is required" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Extract base64 data from data URL
    const base64Data = image.split(",")[1];
    const mimeType = image.split(";")[0].split(":")[1] || "image/jpeg";

    const prompt = `Você é um especialista em gestão de resíduos e sustentabilidade. Analise esta imagem e identifique o tipo de resíduo presente.

Responda APENAS em formato JSON válido (sem markdown ou código) com a seguinte estrutura exata:
{
  "name": "Nome do resíduo identificado (ex: Garrafa PET, Lata de Alumínio, Papelão)",
  "category": "Uma das categorias: Plastico, Papel, Metal, Vidro, Organico, Eletronico, Bateria, Oleo, Farmaceutico, Borracha, Outro",
  "recyclable": true ou false,
  "decompositionTime": "Tempo estimado de decomposição na natureza (ex: 450 anos, 2-5 meses, Indeterminado)",
  "environmentalImpact": "Um dos valores: Baixo, Medio, Alto, Muito Alto",
  "correctDisposal": "Instruções detalhadas de como descartar corretamente este resíduo",
  "caresNeeded": "Cuidados especiais necessários ao manusear ou descartar",
  "confidence": número de 0 a 100 indicando a confiança da identificação
}

Se não conseguir identificar claramente o resíduo, use "Outro" como categoria e forneça orientações gerais.`;

    // Call Gemini API
    const geminiResponse = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${GEMINI_API_KEY}`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          contents: [
            {
              parts: [
                { text: prompt },
                {
                  inline_data: {
                    mime_type: mimeType,
                    data: base64Data,
                  },
                },
              ],
            },
          ],
          generationConfig: {
            temperature: 0.4,
            maxOutputTokens: 1024,
          },
        }),
      }
    );

    if (!geminiResponse.ok) {
      const errorData = await geminiResponse.text();
      console.error("Gemini API error:", errorData);
      return new Response(
        JSON.stringify({ error: "Failed to analyze image with AI" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const geminiData = await geminiResponse.json();
    const textResponse = geminiData.candidates?.[0]?.content?.parts?.[0]?.text;

    if (!textResponse) {
      return new Response(
        JSON.stringify({ error: "No response from AI" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Parse the JSON response from Gemini
    let identification: WasteIdentification;
    try {
      // Clean the response - remove any markdown code blocks if present
      let cleanedResponse = textResponse.trim();
      if (cleanedResponse.startsWith("```json")) {
        cleanedResponse = cleanedResponse.slice(7);
      }
      if (cleanedResponse.startsWith("```")) {
        cleanedResponse = cleanedResponse.slice(3);
      }
      if (cleanedResponse.endsWith("```")) {
        cleanedResponse = cleanedResponse.slice(0, -3);
      }
      cleanedResponse = cleanedResponse.trim();

      identification = JSON.parse(cleanedResponse);
    } catch (parseError) {
      console.error("Failed to parse AI response:", textResponse);
      // Fallback to a generic response
      identification = {
        name: "Resíduo Não Identificado",
        category: "Outro",
        recyclable: false,
        decompositionTime: "Indeterminado",
        environmentalImpact: "Medio",
        correctDisposal: "Descarte em lixo comum ou procure orientação da prefeitura local.",
        caresNeeded: "Em caso de dúvida sobre o tipo de resíduo, evite contato direto e consulte um especialista.",
        confidence: 30,
      };
    }

    // Ensure all fields have values
    const result: WasteIdentification = {
      name: identification.name || "Resíduo Não Identificado",
      category: identification.category || "Outro",
      recyclable: identification.recyclable ?? false,
      decompositionTime: identification.decompositionTime || "Indeterminado",
      environmentalImpact: identification.environmentalImpact || "Medio",
      correctDisposal: identification.correctDisposal || "Descarte em lixo comum.",
      caresNeeded: identification.caresNeeded || "Manusear com cuidado.",
      confidence: Math.min(100, Math.max(0, identification.confidence || 50)),
    };

    return new Response(
      JSON.stringify(result),
      {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  } catch (error) {
    console.error("Error in identify-waste function:", error);
    return new Response(
      JSON.stringify({ error: "Internal server error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
